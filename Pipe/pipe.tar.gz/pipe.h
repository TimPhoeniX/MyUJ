#ifndef _PIPE_H_
#define _PIPE_H_

void read_pipe(int pipedes);
void write_pipe(int pipedes);

#endif